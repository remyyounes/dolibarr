// =========================
// ======== TICKET =========
// =========================

function TableTicket()
{

	// Initialization
	this.init = function(ticket)
	{
		this.ticket = ticket;
		this.ticket.init();
		this.formHolder = document.querySelector("#ticket_input tbody");
		this.itemTable = document.querySelector("#ticket_list");

	}, this.edit = function(rowid)
	{
		this.ticket.edit(rowid);
		this.formHolder.innerHTML = this.ticket.getItem(rowid).editForm();

	}, this.save = function()
	{
		var result = this.ticket.save();
		var status = result[0];
		var item = result[1];
		var type = result[2];

		if (status == "ok") {
			if (type == "create") {
				this.append(item);
			} else if (type == "update") {
				this.updateRow(item);
			}
			this.cancel();
		}

	}, this.cancel = function()
	{
		this.ticket.cancel();
		this.formHolder.innerHTML = this.printDefaultForm();

	}, this.updateRow = function(item)
	{
		this.itemTable.replaceChild(item.printRow(), item.getTableRow());

	}, this.append = function(item)
	{
		this.ticket.append(item);
		this.itemTable.appendChild(item.printRow());

	}, this.printDefaultForm = function()
	{
		var form = "";
		form += '<tr>';
		form += '	<td colspan="7" class="search">';
		form += '		<input type="search" autofocus >';
		form += '	<a class="awesome grey">Chercher</a>';
		form += '	<a onclick="getTicket().freeEntryForm();" class="awesome blue">Entree Libre</a>';
		form += '	</td>';
		form += '</tr>';
		return form;

	}, this.freeEntryForm = function()
	{
		var freeItem = newTicketItem();
		this.formHolder.innerHTML = freeItem.createForm();
		this.ticket.items[freeItem.getRowId()] = freeItem;
		this.ticket.editing = freeItem;

	}, this.updateItemFields = function(field, extra)
	{
		this.ticket.updateItemFields(field, extra);

	}
}

// =========================
// ====== HELPER FUNCS =====
// =========================
function newTicketItem()
{
	var ttItem = new TableTicketItem();
	ttItem.init(new TicketItem());
	return ttItem;
}

// =========================
// ====== TICKET ITEM ======
// =========================

function TableTicketItem()
{
	this.init = function(ticketItem)
	{
		this.ticketItem = ticketItem;
		this.ticketItem.init();
		this.initForm();

	}, this.initForm = function()
	{

		// labels
		this.labels = new Array();
		this.labels['libelle'] = "Libelle";
		this.labels['ht'] = "Px HT";
		this.labels['qte'] = "Qte";
		this.labels['rempct'] = "%";
		this.labels['rem'] = "Rem";
		this.labels['total'] = "Total";
		this.labels['productSearch'] = "Libelle, Reference, CodeBarre";

		// inputTypes
		this.inputTypes = new Array();
		this.inputTypes['libelle'] = "search";
		this.inputTypes['ht'] = "number";
		this.inputTypes['qte'] = "number";
		this.inputTypes['rempct'] = "number";
		this.inputTypes['rem'] = "number";
		this.inputTypes['total'] = "number";
		this.defaultInputType = "number";

		// CSS style
		this.editClass = "edit";

	}, this.edit = function()
	{
		this.ticketItem.edit();
		if (this.getTableRow()) {
			this.getTableRow().classList.add(this.editClass);
		}

	}, this.cancelEdit = function()
	{
		this.ticketItem.cancelEdit();
		if (this.getTableRow()) {
			this.getTableRow().classList.remove(this.editClass);
		}

	}, this.printRow = function()
	{
		var options = new Array();
		var fields = new Array();
		options['type'] = 'text';

		fields.push(this.showField("libelle", options));
		fields.push(this.showField("extra", options));
		fields.push(this.showField("ht", options));
		fields.push(this.showField("qte", options));
		fields.push(this.showField("rempct", options));
		fields.push(this.showField("rem", options));
		fields.push(this.showField("total", options));

		// create Dom TR element
		var row = document.createElement("tr");
		var t = getTicket();
		var id = this.ticketItem.getRowId();
		row.onclick = function()
		{
			t.edit(id)
		};
		row.innerHTML = fields.join("");
		row.id = "rowid_" + this.getRowId();
		return row;

	}, this.createForm = function()
	{
		var options = new Array();
		var emptyTd = "<td></td>";
		options['autofocus'] = 'autofocus';
		options['disabled'] = '';
		options['min'] = '';
		options['btns'] = '';
		var fields = new Array();

		options['type'] = 'input';
		fields.push(this.showField("libelle", options));
		options['min'] = ' min = "0" ';
		fields.push(emptyTd);
		fields.push(this.showField("ht", options));
		fields.push(this.showField("qte", options));
		fields.push(emptyTd);
		fields.push(emptyTd);
		options['disabled'] = 'disabled';
		options['btns'] = this.showInputButtons();
		fields.push(this.showField("total", options));

		var form = "<tr>" + fields.join("") + "</tr>";
		return form;

	}, this.editForm = function()
	{
		var options = new Array();
		options['autofocus'] = 'autofocus';
		options['disabled'] = '';
		options['min'] = '';
		options['btns'] = '';
		var fields = new Array();

		options['type'] = 'text';
		fields.push(this.showField("libelle", options));
		options['type'] = 'input';
		options['min'] = ' min = "0" ';

		fields.push(this.showField("extra", options));
		options['autofocus'] = '';
		fields.push(this.showField("ht", options));
		fields.push(this.showField("qte", options));
		fields.push(this.showField("rempct", options));
		fields.push(this.showField("rem", options));
		options['disabled'] = 'disabled';
		options['btns'] = this.showInputButtons();
		fields.push(this.showField("total", options));

		var form = "<tr>" + fields.join("") + "</tr>";
		return form;

	}, this.showField = function(field, options)
	{
		// extra content needs to be treated slightly differently
		if (field == "extra") {
			return this.showExtraFields(options);
		}

		var out = "";
		if (options['type'] == "text") {
			var v = this.ticketItem[field];
			if (!v) {
				v = 0;
			}
			out += v;

		} else if (options['type'] == "input") {
			out += this.showInput(field, v, options);
		}

		if (options['btns']) {
			out = "<td class='confirm'>" + options['btns'] + out + "</td>";
		} else {
			out = "<td>" + out + "</td>";
		}
		return out;

	}, this.showExtraFields = function(options)
	{
		var variables = getVariables(this.ticketItem.fmcal);

		var out = "";

		for ( var i = 0; i < variables.length; i++) {
			var f = variables[i];
			var v = this.ticketItem.extra[variables[i]];

			if (options['type'] == "text") {
				if (!v) {
					v = 0;
				}
				out += '<div class="extra">';
				out += '<span class="info_header">' + f + '</span>' + v + '</div>';
			} else if (options['type'] == "input") {
				options['extra'] = "extra";

				out += this.showInput(f, v, options);
				options['extra'] = "";
			}
		}
		out = "<td class='extra_input'>" + out + "</td>";
		return out;

	},
	// if autofocus is set it will be unset on return
	this.showInput = function(field, value, options)
	{
		var hide = '';
		if (value || value === 0) {
			hide = ' class = "hide"';
		}

		var extra = '';
		if (options['extra']) {
			extra = ", 'extra'";
		}
		out = '<div>';
		out += '<label' + hide + '>' + this.getFieldLabel(field) + '</label>';
		out += '<input type="' + this.getInputType(field) + '" value="' + value + '" ' + options['autofocus'] + ' ' + options['disabled']
				+ ' ' + options['min'] + ' name="' + field + '"  oninput="getTicket().updateItemFields( this' + extra + ');" />';
		out += '</div>';
		if (options['autofocus']) {
			options['autofocus'] = '';
		}
		return out;

	}, this.getFieldLabel = function(field)
	{
		var l = this.labels[field];
		if (!l) {
			l = field;
		}
		return l;

	}, this.getInputType = function(field)
	{
		var t = this.inputTypes[field];
		if (!t) {
			t = this.defaultInputType;
		}
		return t;

	}, this.showInputButtons = function()
	{
		var out = "";
		out += '<a onclick="getTicket().save();" class="awesome confirm blue">OK</a>';
		out += '<a onclick="getTicket().cancel();" class="awesome confirm red cancel">C</a>';
		return out;

	}, this.getTableRow = function()
	{
		var tr = document.querySelector("#rowid_" + this.ticketItem.getRowId());
		return tr;

	}, this.updateFields = function(f, extraField)
	{
		this.ticketItem.updateFields(f, extraField);
		this.refreshFields();

	}, this.setRemiseMax = function()
	{
		this.ticketItem.setRemiseMax();

	}, this.updateRemise = function()
	{
		this.ticketItem.updateRemise();

	}, this.updateRemisePct = function()
	{
		this.ticketItem.updateRemisePct();

	}, this.updatePrixRemise = function()
	{
		this.ticketItem.updatePrixRemise();

	}, this.updateTotal = function()
	{
		this.ticketItem.updateTotal();

	}, this.updateQuantite = function()
	{
		this.ticketItem.updateQuantite();

	}, this.refreshFields = function()
	{
		var formInputs = document.querySelectorAll("#ticket_input tbody input");
		for ( var i = 0; i < formInputs.length; i++) {
			var inpt = formInputs[i];
			var n = inpt.name;
			if (this.ticketItem[n] != undefined) {
				inpt.value = this.ticketItem[n];
			} else {
				// extra
				this.refreshExtraField(inpt);
			}
			this.checkLabel(inpt);
		}

	}, this.refreshExtraField = function(inpt)
	{
		for ( var i in this.ticketItem.extra) {
			if (i == inpt.name) {
				this.ticketItem.extra[i] = inpt.value;
			}
		}

	}, this.checkLabel = function(inpt)
	{
		var l = inpt.previousSibling;
		if (l.nodeName == "LABEL") {
			if (inpt.value != "") {
				l.classList.add("hide");
			} else {
				l.classList.remove("hide");
			}
		}

	}, this.getRowId = function()
	{
		return this.ticketItem.getRowId();

	}, this.setRowId = function(id)
	{
		return this.ticketItem.setRowId(id);

	}
}