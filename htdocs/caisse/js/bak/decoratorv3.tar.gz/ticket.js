// =========================
// ======== TICKET =========
// =========================

function Ticket()
{

	// Initialization
	this.init = function()
	{
		// STRUCTURE
		this.items = new Array();
		this.forms = new Array();
		this.editing;

	}, this.edit = function(rowid)
	{
		this.cancel();
		var item = this.getItem(rowid);
		item.edit();
		this.editing = item;

	}, this.save = function()
	{
		if (this.editing) {
			if (this.editing.getRowId() > 0) {
				return new Array("ok", this.editing, "update")
			} else {
				this.append(this.editing);
				return new Array("ok", this.editing, "create")
			}
		}
		this.cancel();

	}, this.cancel = function()
	{
		if (this.editing) {
			this.editing.cancelEdit();
			this.editing = '';
		}

	}, this.getItem = function(rowid)
	{
		return this.items[rowid];

	}, this.getItems = function()
	{
		return this.items;

	}, this.append = function(item)
	{
		if (item.getRowId() < 1) {
			if (this.items.length == 0) {
				item.setRowId(1);
			} else {
				item.setRowId(this.items.length);
			}
		}
		this.items[item.getRowId()] = item;

	}, this.updateItemFields = function(field, extra)
	{
		var item = this.editing;
		item.updateFields(field, extra);
	}
}

// =========================
// ====== TICKET ITEM ======
// =========================

function TicketItem()
{
	this.init = function()
	{
		this.initForm();
		this.libelle = "Unlabelled";
		this.prodId = -1;
		this.qte = 1;
		this.ht;
		this.tax;
		this.remise;
		this.remisePct;
		this.extra = new Array();
		this.prixRemise;
		this.total;
		this.rowid = -1;
		this.fmcal = "#{" + "Longueur * Largeur * Epaisseur" + "}";
	}, this.initForm = function()
	{

		// labels
		this.labels = new Array();
		this.labels['libelle'] = "Libelle";
		this.labels['ht'] = "Px HT";
		this.labels['qte'] = "Qte";
		this.labels['rempct'] = "%";
		this.labels['rem'] = "Rem";
		this.labels['total'] = "Total";
		this.labels['productSearch'] = "Libelle, Reference, CodeBarre";

		// inputTypes
		this.inputTypes = new Array();
		this.inputTypes['libelle'] = "search";
		this.inputTypes['ht'] = "number";
		this.inputTypes['qte'] = "number";
		this.inputTypes['rempct'] = "number";
		this.inputTypes['rem'] = "number";
		this.inputTypes['total'] = "number";
		this.defaultInputType = "number";

		// CSS style
		this.editClass = "edit";
		this.rowClass = "alternateRow";
		this.formLabelClass = "inline_label";
	}, this.edit = function()
	{

	}, this.cancelEdit = function()
	{

	}, this.updateFields = function(f, extraField)
	{
		if (extraField) {
			var variables = getVariables(this.fmcal);
			for ( var i in variables) {
				if (variables[i] == f.name) {
					this.extra[variables[i]] = f.value;
				}
			}
			this.updateQuantite();
		} else {
			this[f.name] = f.value;
		}

		if (f.name == "rem") {
			this.updateRemisePct();
		}

		if (f.name == "rempct") {
			this.updateRemise();
		}

		if (f.name == "ht") {
			this.updatePrixRemise();
		}

		// checkRemise
		if (this.prixRemise < 0) {
			this.setRemiseMax();
		}
		this.updateTotal();

	}, this.setRemiseMax = function()
	{
		if (this.ht > 0) {
			this.rem = this.ht;
			this.updateRemisePct();
		} else {
			this.rem = 0;
			this.rempct = 0;
			this.prixRemise = 0;
		}
		this.updateTotal();

	}, this.updateRemise = function()
	{
		if (this.rempct) {
			this.rem = this.ht * this.rempct / 100;
		}
		this.updatePrixRemise();

	}, this.updateRemisePct = function()
	{
		if (this.rem) {
			this.rempct = this.rem * 100 / this.ht;
		}
		this.updatePrixRemise();

	}, this.updatePrixRemise = function()
	{
		if (this.rem) {
			this.prixRemise = this.ht - this.rem;
		} else {
			this.prixRemise = this.ht;
		}

	}, this.updateTotal = function()
	{
		if (!this.prixRemise && this.rem != this.ht) {
			this.prixRemise = this.ht;
		}
		this.total = this.prixRemise * this.qte;

	}, this.updateQuantite = function()
	{
		if (this.fmcal) {
			var mappings = new Object();
			var variables = getVariables(this.fmcal);

			var nbdec = 3;// ('nbdec').value;
			for ( var i = 0; i < variables.length; i++) {
				mappings[variables[i]] = this.extra[variables[i]];
				// valueFormat($('dim'+(i+1)),nbdec);
			}
			var r = evaluate(this.fmcal, mappings);
			this.qte = r;
		}

	}, this.getRowId = function()
	{
		return this.rowid;

	}, this.setRowId = function(id)
	{
		this.rowid = id;

	}
}