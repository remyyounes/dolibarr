// =========================
// ======== TICKET =========
// =========================

function TableTicket(ticket)
{

	this.ticket = ticket;
	// Initialization
	this.init = function()
	{
		this.ticket.init();
		this.formHolder = document.querySelector("#ticket_input tbody");
		this.itemTable  = document.querySelector("#ticket_list");

	}, this.edit = function(rowid)
	{
		this.ticket.edit(rowid);

	}, this.save = function()
	{
		this.ticket.save();

	}, this.cancel = function()
	{
		this.ticket.cancel();

	}, this.updateRow = function(item)
	{
		this.ticket.updateRow(item);

	}, this.append = function(item)
	{
		this.ticket.append(item);

	}, this.printDefaultForm = function()
	{
		this.ticket.printDefaultForm();

	}, this.freeEntryForm = function()
	{
		this.ticket.freeEntryForm();

	}, this.styleRows = function()
	{
		this.ticket.styleRows();

	}, this.updateItemFields = function(field, extra)
	{
		this.ticket.updateItemFields(field, extra);

	}
}