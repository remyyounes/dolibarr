// =========================
// ======== TICKET =========
// =========================

function TableTicket(ticket)
{

	this.ticket = ticket;
	// Initialization
	this.init = function()
	{
		this.ticket.init();
		this.formHolder = document.querySelector("#ticket_input tbody");
		this.itemTable = document.querySelector("#ticket_list");

	}, this.edit = function(rowid)
	{
		this.ticket.edit(rowid);
		this.formHolder.innerHTML = this.ticket.getItem(rowid).editForm();

	}, this.save = function()
	{
		var result = this.ticket.save();
		var status = result[0];
		var item = result[1];
		var type = result[2];

		if (status == "ok") {
			if (type == "create") {
				this.append(item);
			} else if (type == "update") {
				this.updateRow(item);
			}
			this.cancel();
		}

	}, this.cancel = function()
	{
		this.ticket.cancel();
		this.formHolder.innerHTML = this.printDefaultForm();

	}, this.updateRow = function(item)
	{
		this.itemTable.replaceChild(item.printRow(), item.getTableRow());
		this.styleRows();

	}, this.append = function(item)
	{
		this.ticket.append(item);
		this.itemTable.appendChild(item.printRow());
		this.styleRows();

	}, this.printDefaultForm = function()
	{
		var form = "";
		form += '<tr class="alternateRow">';
		form += '	<td colspan="7" class="search">';
		form += '		<input type="search" autofocus >';
		form += '	<a class="awesome grey">Chercher</a>';
		form += '	<a onclick="getTicket().freeEntryForm();" class="awesome blue">Entree Libre</a>';
		form += '	</td>';
		form += '</tr>';
		return form;

	}, this.freeEntryForm = function()
	{
		var freeItem = new TicketItem();
		freeItem.init();
		this.formHolder.innerHTML = freeItem.createForm();
		this.ticket.items[freeItem.rowid] = freeItem;
		this.ticket.editing = freeItem;

	}, this.styleRows = function()
	{
		var trs = this.itemTable.getElementsByTagName("tr");
		for ( var j = 0; j < trs.length; j++) {
			removeClassName(trs[j], 'alternateRow');
			addCSSClass(trs[j], 'normalRow');
		}
		for ( var k = 0; k < trs.length; k += 2) {
			removeClassName(trs[k], 'normalRow');
			addCSSClass(trs[k], 'alternateRow');
		}

	}, this.updateItemFields = function(field, extra)
	{
		this.ticket.updateItemFields(field, extra);

	}
}