// =========================
// ======== TICKET =========
// =========================

function Ticket()
{

	// Initialization
	this.init = function()
	{
		// STRUCTURE
		this.items = new Array();
		this.forms = new Array();
		this.editing;
		this.numItems = 0;
		this.ticketId = -1;

	}, this.edit = function(rowid)
	{
		this.cancel();
		var item = this.getItem(rowid);
		item.edit();
		this.editing = item;

	}, this.save = function()
	{
		if (this.editing) {
			if (this.editing.getRowId() > 0) {
				return new Array("ok", this.editing, "update")
			} else {
				this.append(this.editing);
				return new Array("ok", this.editing, "create")
			}
		}
		this.cancel();

	}, this.cancel = function()
	{
		if (this.editing) {
			this.editing.cancelEdit();
			this.editing = '';
		}

	}, this.getItem = function(rowid)
	{
		return this.items[rowid];

	}, this.getItems = function()
	{
		return this.items;

	}, this.append = function(item)
	{
		if (item.getRowId() < 1) {
			if (this.numItems == 0) {
				item.setRowId(1);
			} else {
				item.setRowId(this.items.length);
			}
		}
		this.items[item.getRowId()] = item;
		this.numItems++;

	}, this.updateItemFields = function(field, extra)
	{
		var item = this.editing;
		item.updateFields(field, extra);

	}, this.clear = function()
	{
		this.items = new Array();
		this.numItems = 0;

	}, this.setId = function(id)
	{
		this.ticketId = id;

	}, this.getId = function()
	{
		return this.ticketId;

	}, this.loadTicket = function(ticketId)
	{
		var data = new Object();
		data.ticketId = ticketId;
		sendCaisseAction("loadTicket", data);

	}, this.loadTicketInit = function(ticketId, items)
	{
		for ( var i = 0; i < items.length; i++) {
		}

	}
}

// =========================
// ====== TICKET ITEM ======
// =========================

function TicketItem()
{
	this.init = function()
	{
		this.libelle = "Unlabelled";
		this.prodId = -1;
		this.qte = 1;
		this.ht;
		this.tax;
		this.remise;
		this.remisePct;
		this.prixRemise;
		this.total;
		this.rowid = -1;
		this.fmcal = "#{" + "Longueur * Largeur * Epaisseur" + "}";
		this.extraDecimals = 3;
		this.extra = new Array();

	}, this.edit = function()
	{

	}, this.cancelEdit = function()
	{

	}, this.updateFields = function(f, extraField)
	{
		if (extraField) {
			var variables = getVariables(this.fmcal);
			for ( var i in variables) {
				if (variables[i] == f.name) {
					var val = this.numToMaxDecimals(f.value, this.getExtraDecimals());
					this.extra[variables[i]] = val;
					// alert(this.extra[variables[i]] );
				}
			}
			this.updateQuantite();
		} else {

			var val = this.numToMaxDecimals(f.value, 2);

			if (f.name == "qte") {
				this.setQuantite(val);
			}
			if (f.name == "rem") {
				this.setRemise(val);
			}
			if (f.name == "rempct") {
				this.setRemisePct(val);
			}
			if (f.name == "ht") {
				this.setPrice(val);
			}
			// checkRemise
			if (this.prixRemise < 0) {
				this.setRemiseMax();
			} else {
				// remaining "zero" fix
				this[f.name] = val;
			}

		}
		this.updateTotal();

	}, this.setPrice = function(price)
	{
		if (price > 0) {
			this.ht = price;
		} else {
			this.ht = 0;
		}
		// refresh discount
		this.setRemisePct(this.rempct);

	}, this.setRemiseMax = function()
	{
		if (this.ht > 0) {
			this.setRemise(this.ht);
		} else {
			this.setRemise(0);
		}

	}, this.setRemisePct = function(remisePct)
	{
		if (remisePct > 0) {
			this.rempct = remisePct;
			this.setRemise(this.ht * this.rempct / 100);
		} else {
			this.setRemise(0);
		}

	}, this.setRemise = function(remise)
	{
		remise = this.numToMaxDecimals(remise, 2);

		if (remise > 0) {
			this.rem = remise;
			this.rempct = this.numToMaxDecimals(this.rem * 100 / this.ht, 2);
			this.prixRemise = this.ht - this.rem;
		} else {
			this.rem = 0;
			this.rempct = 0;
			this.prixRemise = this.ht;
		}
		/*
		 * }, this.updatePrixRemise = function() { if (this.rem) {
		 * this.prixRemise = this.ht - this.rem; } else { this.prixRemise =
		 * this.ht; }
		 */
	}, this.setQuantite = function(quantite)
	{
		this.qte = quantite ? quantite : 0;

	}, this.updateTotal = function()
	{
		if (!this.prixRemise && this.rem != this.ht) {
			this.prixRemise = this.ht;
		}
		this.total = this.numToMaxDecimals(this.prixRemise * this.qte, 2);

	}, this.updateQuantite = function()
	{
		if (this.fmcal) {
			var mappings = new Object();
			var variables = getVariables(this.fmcal);

			var nbdec = 3;// ('nbdec').value;
			for ( var i = 0; i < variables.length; i++) {
				mappings[variables[i]] = this.extra[variables[i]];
				// valueFormat($('dim'+(i+1)),nbdec);
			}
			var r = evaluate(this.fmcal, mappings);
			this.qte = this.numToMaxDecimals(r, this.getExtraDecimals());
		}

	}, this.numToMaxDecimals = function(n, ndec)
	{
		var s = n.toLocaleString();
		var dotPos = s.lastIndexOf(".");
		if (s.length != dotPos + 1) {
			var dec = s.split(".")[1];
			if (dec > ndec) {
				n = parseFloat(n).toFixed(ndec);
			}
		}
		return n;

	}, this.formatField = function(f)
	{
		this.e
	}

	, this.getRowId = function()
	{
		return this.rowid;

	}, this.setRowId = function(id)
	{
		this.rowid = id;

	}, this.setLibelle = function(libelle)
	{
		this.libelle = libelle;

	}, this.getLibelle = function()
	{
		return this.libelle;

	}, this.setExtraDecimals = function(dec)
	{
		this.extraDecimals = dec;

	}, this.getExtraDecimals = function()
	{
		return this.extraDecimals;

	}, this.isExtraField = function(field)
	{
		return getVariables(this.fmcal).contains(field);

	}, this.loadFromJson = function(data)
	{
		this.rowid = data.rowid;
		// var $desc;
		this.prodid = data.fk_product; // Id of predefined product
		this.qty = data.qty; // Quantity (example 2)
		this.qtyc = data.qtyc; // Quantite de Colis
		this.ht = data.subprice;
		this.rempct = data.remise_percent;
		this.rang = data.rang;
		this.total = data.total_ht;
		this.prixRemise = data.price;
		this.rem = data.remise;;
		this.libelle = data.libelle;
		
		this.extra = data.extra;

	}
}