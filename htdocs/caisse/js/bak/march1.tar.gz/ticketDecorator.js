// =========================
// ======== TICKET =========
// =========================

function TableTicket()
{

	// Initialization
	this.init = function(ticket)
	{
		this.ticket = ticket;
		this.ticket.init();
		this.formHolder = document.querySelector("#ticket_input tbody");
		this.itemTable = document.querySelector("#ticket_list");

	}, this.edit = function(rowid)
	{
		this.ticket.edit(rowid);
		this.formHolder.innerHTML = this.ticket.getItem(rowid).editForm();
		this.ticket.getItem(rowid).refreshFields();

	}, this.save = function()
	{
		var result = this.ticket.save();
		var status = result[0];
		var item = result[1];
		var type = result[2];

		if (status == "ok") {
			if (type == "create") {
				this.append(item);
			} else if (type == "update") {
				this.updateRow(item);
			}
			this.cancel();
		}

	}, this.cancel = function()
	{
		this.ticket.cancel();
		this.formHolder.innerHTML = this.printDefaultForm();

	}, this.updateRow = function(item)
	{
		this.itemTable.replaceChild(item.printRow(), item.getTableRow());

	}, this.append = function(item)
	{
		this.ticket.append(item);
		this.itemTable.appendChild(item.printRow());

	}, this.printDefaultForm = function()
	{
		var form = "";
		form += '<tr>';
		form += '	<td colspan="7" class="search">';
		form += '		<input type="search" autofocus >';
		form += '	<a class="awesome grey">Chercher</a>';
		form += '	<a onclick="getTicket().freeEntryForm();" class="awesome blue">Entree Libre</a>';
		form += '	</td>';
		form += '</tr>';
		return form;

	}, this.freeEntryForm = function()
	{
		var freeItem = newTicketItem();
		this.formHolder.innerHTML = freeItem.createForm();
		this.ticket.items[freeItem.getRowId()] = freeItem;
		this.ticket.editing = freeItem;
		freeItem.refreshFields();

	}, this.updateItemFields = function(field, extra)
	{
		this.ticket.updateItemFields(field, extra);
		this.ticket.editing.refreshFields();

	}, this.clear = function()
	{
		this.itemTable.innerHTML = '';
		this.ticket.clear();

	}, this.setId = function(id)
	{
		this.ticket.setId(id);
		document.querySelector("#ticketId").innerHTML = id;
		alert(id);

	}, this.getId = function()
	{
		return this.ticket.getId();

	}, this.loadTicket = function(ticketId)
	{
		this.ticket.loadTicket(ticketId);

	}, this.populateTicket = function(ticketId, json_items)
	{
		for ( var i = 0; i < json_items.length; i++) {
			var item = newTicketItem();
			
		}
	}
}

// =========================
// ====== HELPER FUNCS =====
// =========================
function newTicketItem()
{
	var ttItem = new TableTicketItem();
	ttItem.init(new TicketItem());
	return ttItem;
}

// =========================
// ====== TICKET ITEM ======
// =========================

function TableTicketItem()
{
	this.init = function(ticketItem)
	{
		this.ticketItem = ticketItem;
		this.ticketItem.init();
		this.initForm();

	}, this.initForm = function()
	{

		// labels
		this.labels = new Array();
		this.labels['libelle'] = "Libelle";
		this.labels['ht'] = "Px HT";
		this.labels['qte'] = "Qte";
		this.labels['rempct'] = "%";
		this.labels['rem'] = "Rem";
		this.labels['total'] = "Total";
		this.labels['productSearch'] = "Libelle, Reference, CodeBarre";

		// inputTypes
		this.inputOptions = new Array();
		this.defaultInputOptions = ' type="number" min="0" ';
		this.inputOptions['libelle'] = ' type="search" autofocus ';
		this.inputOptions['ht'] = this.defaultInputOptions;
		this.inputOptions['qte'] = this.defaultInputOptions;
		this.inputOptions['rempct'] = ' type="number" min="0" step="1" ';
		this.inputOptions['rem'] = this.defaultInputOptions;
		this.inputOptions['total'] = this.defaultInputOptions;

		// Disabled Fields
		this.disabledInputs = new Array("total");

		// CSS style
		this.editClass = "edit";

	}, this.edit = function()
	{
		this.ticketItem.edit();
		if (this.getTableRow()) {
			this.getTableRow().classList.add(this.editClass);
		}

	}, this.cancelEdit = function()
	{
		this.ticketItem.cancelEdit();
		if (this.getTableRow()) {
			this.getTableRow().classList.remove(this.editClass);
		}

	}, this.printRow = function()
	{
		var fields = new Array();

		fields.push(this.showField("libelle"));
		fields.push(this.showExtraFields());
		fields.push(this.showField("ht"));
		fields.push(this.showField("qte"));
		fields.push(this.showField("rempct"));
		fields.push(this.showField("rem"));
		fields.push(this.showField("total"));

		// create Dom TR element
		var row = document.createElement("tr");
		var t = getTicket();
		var id = this.getRowId();
		row.onclick = function()
		{
			t.edit(id)
		};
		row.innerHTML = fields.join("");
		row.id = "rowid_" + this.getRowId();
		return row;

	}, this.createForm = function()
	{
		var emptyTd = "<td></td>";
		var fields = new Array();

		// create row
		fields.push(this.showInput("libelle"));
		fields.push(emptyTd);
		fields.push(this.showInput("ht"));
		fields.push(this.showInput("qte"));
		fields.push(emptyTd);
		fields.push(emptyTd);
		fields.push(this.showInput("total"));

		// print row/form
		var form = "<tr>" + fields.join("") + "</tr>";
		return form;

	}, this.editForm = function()
	{
		var fields = new Array();

		// create row
		fields.push(this.showField("libelle"));
		fields.push(this.showExtraInputs());
		fields.push(this.showInput("ht"));
		fields.push(this.showInput("qte"));
		fields.push(this.showInput("rempct"));
		fields.push(this.showInput("rem"));
		fields.push(this.showInput("total"));

		// print row/form
		var form = "<tr>" + fields.join("") + "</tr>";
		return form;

	}, this.showField = function(field)
	{
		var v = this.ticketItem[field];
		var out = (!v) ? 0 : v;
		return "<td>" + out + "</td>";

	}, this.showExtraFields = function()
	{
		var variables = getVariables(this.ticketItem.fmcal);
		var out = "";
		for ( var i = 0; i < variables.length; i++) {
			var f = variables[i];
			var v = this.ticketItem.extra[variables[i]];
			v = (!v) ? 0 : v;
			out += '<div class="extra">';
			out += '<span class="info_header">' + f + '</span>' + v + '</div>';
		}

		out = "<td>" + out + "</td>";
		return out;
	}, this.showExtraInputs = function()
	{
		var variables = getVariables(this.ticketItem.fmcal);
		var out = "";

		for ( var i = 0; i < variables.length; i++) {
			var f = variables[i];
			var v = this.ticketItem.extra[variables[i]];

			out += this.showInput(f);
		}
		out = "<td>" + out + "</td>";
		return out;

	}, this.showInput = function(field)
	{
		// get correct value
		var value = '';
		if (this.isExtraField(field)) {
			value = this.ticketItem.extra[field];
		} else {
			value = this.ticketItem[field];
		}

		// =====================
		// ===== IMPORTANT =====
		// =====================
		// Values are not set on Input creating due to a Chromium bug
		// Instead, values are initialized by TableTicketItem.refreshFields()
		value = (value == undefined) ? '' : value;

		// For now we set value to the empty string
		value = '';
		// =====================

		// Input Data
		var fieldName = ' name="' + field + '" ';
		var isDisabled = (this.isInputEnabled(field)) ? '' : ' disabled ';
		var hide = (value || value === 0) ? ' class = "hide"' : '';
		var extra = (this.isExtraField(field)) ? ", 'extra'" : '';
		var oninput = ' oninput="getTicket().updateItemFields(this' + extra + ');"  ';
		var onblur = ' onblur="getTicket().updateItemFields(this' + extra + ');"  ';

		// print
		var out = "";
		if (field == 'total') {
			out = this.showInputButtons() + out;
		}
		out += '<div>';
		out += '<label' + hide + '>' + this.getFieldLabel(field) + '</label>';
		out += '<input ' + this.getInputOptions(field) + fieldName + isDisabled + oninput + onblur + ' value="' + value + '"  />';
		out += '</div>';
		if (!extra) {
			out = "<td>" + out + "</td>"
		}
		return out;

	}, this.getFieldLabel = function(field)
	{
		var l = this.labels[field];
		if (!l) {
			l = field;
		}
		return l;

	}, this.getInputOptions = function(field)
	{
		var t = this.inputOptions[field];
		if (!t) {
			t = this.defaultInputOptions;
		}
		return t;

	}, this.showInputButtons = function()
	{
		var out = "";
		out += '<a onclick="getTicket().save();" class="awesome confirm blue">OK</a>';
		out += '<a onclick="getTicket().cancel();" class="awesome confirm red cancel">C</a>';
		return out;

	}, this.getTableRow = function()
	{
		return document.querySelector("#rowid_" + this.getRowId());

	}, this.updateFields = function(f, extraField)
	{
		this.ticketItem.updateFields(f, extraField);
		this.refreshFields();

	}, this.refreshFields = function()
	{
		var formInputs = document.querySelectorAll("#ticket_input tbody input");
		for ( var i = 0; i < formInputs.length; i++) {
			var inpt = formInputs[i];
			var n = inpt.name;
			if (this.ticketItem[n] != undefined) {
				inpt.value = this.ticketItem[n];
			} else {
				// extra
				this.refreshExtraField(inpt);
			}
			this.checkLabel(inpt);
		}

	}, this.refreshExtraField = function(inpt)
	{
		for ( var i in this.ticketItem.extra) {
			if (i == inpt.name) {
				inpt.value = this.ticketItem.extra[i];
			}
		}

	}, this.checkLabel = function(inpt)
	{
		var l = inpt.previousSibling;
		if (l.nodeName == "LABEL") {
			if (inpt.value != "") {
				l.classList.add("hide");
			} else {
				l.classList.remove("hide");
			}
		}

	}, this.getRowId = function()
	{
		return this.ticketItem.getRowId();

	}, this.setRowId = function(id)
	{
		return this.ticketItem.setRowId(id);

	}, this.isInputEnabled = function(field)
	{
		return !this.disabledInputs.contains(field);

	}, this.enableInput = function(field)
	{
		if (this.isInputEnabled(field)) {
			this.disabledInputs.push(field);
		}

	}, this.disableInput = function(field)
	{
		this.disabledInputs.remove(field);

	}, this.isExtraField = function(field)
	{
		return this.ticketItem.isExtraField(field);

	}, this.loadFromJson = function(data){
		this.ticketItem.loadFromJson(data);
	
	}
}