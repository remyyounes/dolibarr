// ===============================
// =========== CAISSE ============
// ===============================

function Caisse()
{

	this.init = function()
	{
		this.clientId = -1;
		this.sellerId = -1;
		this.clientName = "Client";
		this.sellerName = "Vendeur";

	}, this.setClient = function(clientId, clientName)
	{
		this.clientId = clientId;
		this.clientName = clientName;

	}, this.getClientId = function()
	{
		return this.clientId;

	}

}

// ==============================
// ======== CAISSE DECO =========
// ==============================

function CaisseDeco()
{

	this.init = function(caisse)
	{
		this.caisse = caisse;
		this.caisse.init();

	}, this.setClient = function(clientId, clientName)
	{
		this.caisse.setClient(clientId, clientName);
		document.querySelector("#client").innerHTML = clientName;

	}, this.getClientId = function()
	{
		return this.caisse.getClientId();

	}

}

// ==============================
// =========== FUNCS ============
// ==============================
var caisse = new CaisseDeco();
caisse.init(new Caisse());
setCaisse(caisse);

function setCaisse(caisse)
{
	caisse = caisse;
}

function getCaisse()
{
	return caisse;
}

function getSelectionList()
{
	return document.querySelector("#selection");
}

function hideSelectionList()
{
	getSelectionList().style.display = "none";
}

function getClientList()
{
	var data = new Object();
	sendCaisseAction("getClientList", data);
}

function getClientTickets()
{
	var data = new Object();
	data.clientId = getCaisse().getClientId();
	sendCaisseAction("getClientTickets", data);
}

function showList(header, data)
{
	var list = getSelectionList();
	list.innerHTML = header;
	list.appendChild(data);
	list.style.display = "block";
	list.innerHTML += listCancelBtn();
}

function showClientTicketList(tickets)
{
	var table = document.createElement("table");
	var trs = new Array();
	var header = "<header><h1>Liste Tickets</h1></header>"
	var thead = "<thead><tr><th>Id</th><th>Numero Ticket</th></thead>"
	var table = document.createElement("table");
	for ( var i = 0; i < tickets.length; i++) {
		onclk = 'onclick="loadTicket(' + tickets[i].id + ');hideSelectionList()"';
		trs.push("<tr " + onclk + "><td>" + tickets[i].id + "</td><td>" + tickets[i].facnumber + "</td></tr>");
	}
	table.innerHTML = thead + trs.join("");

	showList(header, table);
}
function showClientList(clients)
{
	var table = document.createElement("table");
	var trs = new Array();
	var header = "<header><h1>Liste Clients</h1></header>"
	var thead = "<thead><tr><th>Id</th><th>Nom</th></thead>"
	var table = document.createElement("table");
	for ( var i = 0; i < clients.length; i++) {
		onclk = 'onclick="getCaisse().setClient(' + clients[i].id + ',' + "'" + clients[i].name + "'" + ');hideSelectionList()"';
		trs.push("<tr " + onclk + "><td>" + clients[i].id + "</td><td>" + clients[i].name + "</td></tr>");
	}
	table.innerHTML = thead + trs.join("");

	showList(header, table);

}

function listCancelBtn()
{
	return '<a onclick="hideSelectionList()" class="awesome large red listcancel">Annuler</a>';
}

function newTicket()
{
	var clientId = getCaisse().getClientId();
	if (clientId < 0) {
		alert("Client indefini")
		return;
	}
	var data = new Object();
	data.clientId = clientId;
	sendCaisseAction("newTicket", data);
}
function loadTicket(ticketId)
{
	var data = new Object();
	data.ticketId = ticketId;
	sendCaisseAction("loadTicket", data);
}

// =============================
// =========== AJAX ============
// =============================

function sendCaisseAction(action, data)
{
	data.action = action;
	if (action) {

		$.ajax({
			type : 'POST',
			url : 'dolibarrCaisse_ajax.php',
			dataType : 'json',
			data : data,
			success : function(data)
			{
				dispatchServerResponse(data);
			},
			error : function(XMLHttpRequest, textStatus, errorThrown)
			{
				alert("Ajax Error")
				alert(XMLHttpRequest);
				alert(textStatus);
				alert(errorThrown);
			}
		});
	}
}

function dispatchServerResponse(data)
{

	if (data.action == "newTicket") {
		if (data.error) {
			alert("Probleme de creation de ticket")
		}
		var t = getTicket();
		t.clear();
		t.setId(data.ticketId);
	} else if (data.action == "getClientList") {
		showClientList(data.clients);
	} else if (data.action == "getClientTickets") {
		showClientTicketList(data.tickets);
	} else if (data.action == "loadTicket") {
		for(var i = 0; i < data.items.length; i++){
			var item = data.items[i];
			var p = item.price_ht;
			var tItem = newTicketItem();
			tItem.loadFromJson(item);
		}
	}
}
